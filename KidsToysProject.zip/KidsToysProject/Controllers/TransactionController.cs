﻿
//Last Update March 22, 2021

using KidsToysProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace KidsToysProject.Controllers
{
    [Authorize]
    public class TransactionController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        // GET: Transaction
        private Cart GetUsersCart()
        {
            //let the system save the name as the first part of the email
            string username = User.Identity.Name;
            string name = username.Split('@')[0];
            try
            {
                db.Customers.First(c => c.UserName.Equals(username));
            }
            catch (Exception)
            {
                db.Customers.Add(new Customer { UserName = username, Name = name, Points = 0 });
                db.SaveChanges();
            }
            Cart cart = null;
            try
            {
                cart = db.Carts.First(c => c.CustomerName.Equals(username) && c.Status.Equals("unpaid"));
            }
            catch (Exception)
            {
                // no we don't -- create one
                cart = new Cart { CustomerName = username, Status = "unpaid", Date = DateTime.Now };
                db.Carts.Add(cart);
                db.SaveChanges();
            }
            return cart;
        }


        public ActionResult Buy(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);

            if (product == null)
            {
                return HttpNotFound();
            }

            Cart cart = GetUsersCart();
            try
            {
                CartItem cartitem = db.CartItems.First(c => (c.CartId == cart.Id && c.ProductId == product.Id));
                cartitem.Quantity++;
                product.Amount--;
                product.Purchased++;
            }
            catch (Exception)
            {
                CartItem cartitem = new CartItem { ProductId = product.Id, CartId = cart.Id, Quantity = 1 };
                db.CartItems.Add(cartitem);
            }
            db.SaveChanges();
            return RedirectToAction("Details", "CartsUser", new { id = cart.Id });
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //Cart 
        public ActionResult MyCart()
        {
            Cart cart = GetUsersCart();
            return RedirectToAction("Details", "CartsUser", new { id = cart.Id });
        }

        public ActionResult CheckOut(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cart cart = GetUsersCart();
            Customer customer = db.Customers.Find(User.Identity.Name);
            if (cart == null)
            {
                return HttpNotFound();
            }
            if (cart.CartItems.Count() == 0)
            {
                TempData["message"] = "Your cart is Empty!";
                return RedirectToAction("MyCart", "Transaction", new { id = cart.Id });
            }
            else
            {
                int total = 0;
                foreach (var item in cart.CartItems)
                {
                    total += (int)(item.Product.Price * item.Quantity);
                }
                cart.Status = "paid";
                cart.Total = total;
                customer.Points = cart.Total/ 3;
                TempData["total"] = cart.Total;
                TempData["points"] = customer.Points;
                db.SaveChanges();
                TrackOrder trackOrder = new TrackOrder { CartId = cart.Id, Distance = new Random().Next(70, 200), DateOfPurchase = DateTime.Today, DateOfArrival = DateTime.Today.AddDays(4) };
                db.TrackOrders.Add(trackOrder);
                db.SaveChanges();
            }

            return RedirectToAction("Create", "ShipmentAddresses", new { id = cart.Id });
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //TrackOrder

        public ActionResult TrackOrder(int? id)
        {
            Cart cart = db.Carts.Find(id);
                TrackOrder trackOrder = db.TrackOrders.Find(id);
                ViewBag.cart = trackOrder.CartId;
                ViewBag.dist = trackOrder.Distance;
                DateTime dateOfPurchase = trackOrder.DateOfPurchase.Value;
                ViewBag.dateOfpurchase = dateOfPurchase.ToShortDateString();
                DateTime dateOfarrival = trackOrder.DateOfArrival.Value;
                ViewBag.dateOfarrival = dateOfarrival.ToShortDateString();
                double Duration = (dateOfarrival - DateTime.Today).TotalDays;
                ViewBag.TimeTillPackage = Duration;
                ViewBag.half = (trackOrder.Distance) / 2;
            return View();
        }


        public ActionResult DeleteItem(int? id)
        {
            Cart cart = GetUsersCart();
            CartItem cartItem = db.CartItems.Find(id);
            db.CartItems.Remove(cartItem);
            db.SaveChanges();
            return RedirectToAction("Details", "CartsUser", new { id = cart.Id });
        }

        public ActionResult increaseQuantity(int? id)
        {
            Cart cart = GetUsersCart();
            CartItem cartItem = db.CartItems.Find(id);
            cartItem.Quantity = cartItem.Quantity + 1;
            db.SaveChanges();
            return RedirectToAction("Details", "CartsUser", new { id = cart.Id });
        }

        //need to improve
        public ActionResult decreaseQuantity(int? id)
        {
            Cart cart = GetUsersCart();
            CartItem cartItem = db.CartItems.Find(id);
            if (cartItem.Quantity == 1)
            {
                db.CartItems.Remove(cartItem);
                db.SaveChanges();
                return RedirectToAction("Details", "CartsUser", new { id = cart.Id });
            }
            else
            {
                cartItem.Quantity = cartItem.Quantity - 1;
                db.SaveChanges();
                return RedirectToAction("Details", "CartsUser", new { id = cart.Id });
            }
        }

        public ActionResult ShipmentDetails(int? id)
        {

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShipmentAddress shipmentAddress = db.ShipmentAddresses.Find(id);

            if (shipmentAddress == null)
            {
                return HttpNotFound();
            }

            Cart cart = GetUsersCart();
            Shipment shipment = db.Shipments.Find(id);

            // Customer customer = db.Customers.Find(id);
            try
            {
                shipment = db.Shipments.First(c => (c.CustomerName == cart.CustomerName && c.CartId == cart.Id));
            }
            catch (Exception)
            {
                shipment = new Shipment
                {
                    CustomerName = cart.CustomerName,
                    CartId = cart.Id,
                    ShipmentAdressId = shipmentAddress.Id,
                    deliveryCost = 50,
                    status = "Shipped",
                    Date = DateTime.Now
                };
                db.Shipments.Add(shipment);
            }
            db.SaveChanges();
            return RedirectToAction("Details", "Shipments", new { id = shipment.Id });
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //Bookmark 
        private Bookmark GetUsersBookmark(int? id)
        {
            //let the system save the name as the first part of the email
            string username = User.Identity.Name;
            string name = username.Split('@')[0];
            try
            {
                db.Customers.First(c => c.UserName.Equals(username));
            }
            catch (Exception)
            {
                db.Customers.Add(new Customer { UserName = username, Name = name });
                db.SaveChanges();
            }
            Bookmark bookmark = null;
            Product product = db.Products.Find(id);
            try
            {
                bookmark = db.Bookmarks.First(c => c.CustomerName.Equals(username));
            }
            catch (Exception)
            {
                bookmark = new Bookmark { CustomerName = username};
                db.Bookmarks.Add(bookmark);
                db.SaveChanges();
            }
            return bookmark;
        }

        public ActionResult Bookmark(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);

            if (product == null)
            {
                return HttpNotFound();
            }

            Bookmark bookmark = GetUsersBookmark(id);
            try
            {
                BookmarkItem bookmarkitem = db.BookmarkItems.First(c => (c.BookmarkId == bookmark.Id && c.ProductId == product.Id));
            }
            catch (Exception)
            {
                BookmarkItem bookmarkitem = new BookmarkItem { ProductId = product.Id, BookmarkId = bookmark.Id };
                db.BookmarkItems.Add(bookmarkitem);
            }
            db.SaveChanges();
            return RedirectToAction("Details", "Bookmarks", new { id = bookmark.Id });
        }

        public ActionResult MyBookmarks(int? id)
        {
            Bookmark bookmark = GetUsersBookmark(id);
            return RedirectToAction("Details", "Bookmarks", new { id = bookmark.Id });
        }

        public ActionResult DeleteBookmark(int? id)
        {
            Bookmark bookmark = GetUsersBookmark(id);
            BookmarkItem bookmarkItem = db.BookmarkItems.Find(id);
            db.BookmarkItems.Remove(bookmarkItem);
            db.SaveChanges();
            return RedirectToAction("Details", "Bookmarks", new { id = bookmark.Id });
        }

        public ActionResult OrderComplete()
        {
            return View();
        }
    }
}