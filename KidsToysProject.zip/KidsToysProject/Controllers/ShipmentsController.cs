﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KidsToysProject.Models;

namespace KidsToysProject.Controllers
{
    [Authorize]
    public class ShipmentsController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        // GET: Shipments
        public ActionResult Index()
        {
            string username = User.Identity.Name;
            if (username != "admin@admin.com")
            {
                var shipments = db.Shipments.Where(c => c.CustomerName == username);
                return View(shipments.ToList());
            }
            var allShipments = db.Shipments.Include(s => s.Cart).Include(s => s.Customer).Include(s => s.ShipmentAddress);
            return View(allShipments.ToList());
        }

        // GET: Shipments/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Shipment shipment = db.Shipments.Find(id);
            if (shipment == null)
            {
                return HttpNotFound();
            }
            return View(shipment);
        }

        [Authorize(Users = "admin@admin.com")]
        // GET: Shipments/Create
        public ActionResult Create()
        {
            ViewBag.CartId = new SelectList(db.Carts, "Id", "CustomerName");
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name");
            ViewBag.ShipmentAdressId = new SelectList(db.ShipmentAddresses, "Id", "StreetName");
            return View();
        }

        [Authorize(Users = "admin@admin.com")]
        // POST: Shipments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CustomerName,CartId,ShipmentAdressId,deliveryCost,status,Date")] Shipment shipment)
        {
            if (ModelState.IsValid)
            {
                db.Shipments.Add(shipment);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CartId = new SelectList(db.Carts, "Id", "CustomerName", shipment.CartId);
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", shipment.CustomerName);
            ViewBag.ShipmentAdressId = new SelectList(db.ShipmentAddresses, "Id", "StreetName", shipment.ShipmentAdressId);
            return View(shipment);
        }

        // GET: Shipments/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Shipment shipment = db.Shipments.Find(id);
            if (shipment == null)
            {
                return HttpNotFound();
            }
            ViewBag.CartId = new SelectList(db.Carts, "Id", "CustomerName", shipment.CartId);
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", shipment.CustomerName);
            ViewBag.ShipmentAdressId = new SelectList(db.ShipmentAddresses, "Id", "StreetName", shipment.ShipmentAdressId);
            return View(shipment);
        }

        // POST: Shipments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Users = "admin@admin.com")]

        public ActionResult Edit([Bind(Include = "Id,CustomerName,CartId,ShipmentAdressId,deliveryCost,status,Date")] Shipment shipment)
        {
            if (ModelState.IsValid)
            {
                db.Entry(shipment).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CartId = new SelectList(db.Carts, "Id", "CustomerName", shipment.CartId);
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", shipment.CustomerName);
            ViewBag.ShipmentAdressId = new SelectList(db.ShipmentAddresses, "Id", "StreetName", shipment.ShipmentAdressId);
            return View(shipment);
        }

        [Authorize(Users = "admin@admin.com")]
        // GET: Shipments/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Shipment shipment = db.Shipments.Find(id);
            if (shipment == null)
            {
                return HttpNotFound();
            }
            return View(shipment);
        }

        [Authorize(Users = "admin@admin.com")]
        // POST: Shipments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Shipment shipment = db.Shipments.Find(id);
            db.Shipments.Remove(shipment);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
