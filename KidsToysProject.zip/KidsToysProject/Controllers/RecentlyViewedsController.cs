﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KidsToysProject.Models;

namespace KidsToysProject.Controllers
{
    public class RecentlyViewedsController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();
        [Authorize]
        // GET: RecentlyVieweds
        public ActionResult Index()
        {
            
            if (User.Identity.Name == "admin@admin.com")
            {
                var recentlyVieweds = db.RecentlyVieweds.Include(r => r.Customer).Include(r => r.Product);
                return View(recentlyVieweds.ToList());
            }
            else
            {
                var recentlyVieweds = db.RecentlyVieweds.Where(x => x.CustomerName == User.Identity.Name);
                return View(recentlyVieweds.ToList());
            }
            
        }
        [Authorize]
        // GET: RecentlyVieweds/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RecentlyViewed recentlyViewed = db.RecentlyVieweds.Find(id);
            if (recentlyViewed == null)
            {
                return HttpNotFound();
            }
            return View(recentlyViewed);
        }


        [Authorize(Users = "admin@admin.com")]

        // GET: RecentlyVieweds/Create
        public ActionResult Create()
        {
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name");
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name");
            return View();
        }

        // POST: RecentlyVieweds/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,ProductId,CustomerName")] RecentlyViewed recentlyViewed)
        {
            if (ModelState.IsValid)
            {
                db.RecentlyVieweds.Add(recentlyViewed);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", recentlyViewed.CustomerName);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", recentlyViewed.ProductId);
            return View(recentlyViewed);
        }

        [Authorize(Users = "admin@admin.com")]

        // GET: RecentlyVieweds/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RecentlyViewed recentlyViewed = db.RecentlyVieweds.Find(id);
            if (recentlyViewed == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", recentlyViewed.CustomerName);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", recentlyViewed.ProductId);
            return View(recentlyViewed);
        }

        // POST: RecentlyVieweds/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,ProductId,CustomerName")] RecentlyViewed recentlyViewed)
        {
            if (ModelState.IsValid)
            {
                db.Entry(recentlyViewed).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", recentlyViewed.CustomerName);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", recentlyViewed.ProductId);
            return View(recentlyViewed);
        }

        [Authorize(Users = "admin@admin.com")]


        // GET: RecentlyVieweds/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RecentlyViewed recentlyViewed = db.RecentlyVieweds.Find(id);
            if (recentlyViewed == null)
            {
                return HttpNotFound();
            }
            return View(recentlyViewed);
        }

        // POST: RecentlyVieweds/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            RecentlyViewed recentlyViewed = db.RecentlyVieweds.Find(id);
            db.RecentlyVieweds.Remove(recentlyViewed);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
