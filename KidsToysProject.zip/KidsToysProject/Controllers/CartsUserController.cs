﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KidsToysProject.Models;

namespace KidsToysProject.Controllers
{
    [Authorize]
    public class CartsUserController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        // GET: CartUser
        public ActionResult Index()
        {
            var carts = db.Carts.Where(c => c.CustomerName == User.Identity.Name);
            return View(carts.ToList());
        }

        // GET: CartUser/Details/5
        public ActionResult Details(int? id, string discountCode)
        {

            int total = 0;

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cart cart = db.Carts.Find(id);
            if (cart == null)
            {
                return HttpNotFound();
            }
            foreach (var item in cart.CartItems)
            {
                total += (int)(item.Product.Price * item.Quantity);
            }

            if (!String.IsNullOrEmpty(discountCode))
            {
                var v = from e in db.Vouchers
                        select e;
                v = v.Where(e => e.Code.Equals(discountCode));
                // ViewBag.check = v.Count();
                if (v.Count() == 0)
                {
                    ViewBag.check = "Invalied code!";
                }
                else
                {
                    var cusId = User.Identity.Name;
                    var usercart = db.Carts.Where(x => x.CustomerName == cusId && x.Status == "unpaid").First();
                    var oneRecourd = v.First();
                    int afterDiscount = total - (int)(total * oneRecourd.discountPercent) / 100;
                    usercart.Total = total;
                    usercart.afterDiscount = afterDiscount;
                    usercart.Discount = oneRecourd.discountPercent;
                    db.SaveChanges();
                    //ViewBag.AD = afterDiscount;
                    //ViewBag.D = oneRecourd.discountPercent; 
                    ViewBag.check = "Valid code";
                }
            }
            ViewBag.totalAmount = total;
            return View(cart);
        }

        [Authorize(Users="admin@admin.com")]
        // GET: CartUser/Create
        public ActionResult Create()
        {
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name");
            ViewBag.Id = new SelectList(db.Vouchers, "Id", "Code");
            return View();
        }

        // POST: CartUser/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CustomerName,Status,Total,Discount,afterDiscount,Date")] Cart cart)
        {
            if (ModelState.IsValid)
            {
                db.Carts.Add(cart);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", cart.CustomerName);
            ViewBag.Id = new SelectList(db.Vouchers, "Id", "Code", cart.Id);
            return View(cart);
        }

        [Authorize(Users = "admin@admin.com")]
        // GET: CartUser/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cart cart = db.Carts.Find(id);
            if (cart == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", cart.CustomerName);
            ViewBag.Id = new SelectList(db.Vouchers, "Id", "Code", cart.Id);
            return View(cart);
        }

        [Authorize(Users = "admin@admin.com")]
        // POST: CartUser/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,CustomerName,Status,Total,Discount,afterDiscount,Date")] Cart cart)
        {
            if (ModelState.IsValid)
            {
                db.Entry(cart).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", cart.CustomerName);
            ViewBag.Id = new SelectList(db.Vouchers, "Id", "Code", cart.Id);
            return View(cart);
        }

        // GET: CartUser/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Cart cart = db.Carts.Find(id);
            if (cart == null)
            {
                return HttpNotFound();
            }
            return View(cart);
        }

        // POST: CartUser/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Cart cart = db.Carts.Find(id);
            db.Carts.Remove(cart);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
