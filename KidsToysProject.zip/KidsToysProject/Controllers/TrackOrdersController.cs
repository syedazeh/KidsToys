﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KidsToysProject.Models;

namespace KidsToysProject.Controllers
{
    [Authorize(Users = "admin@admin.com")]
    public class TrackOrdersController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        // GET: TrackOrders
        public ActionResult Index()
        {
            var trackOrders = db.TrackOrders.Include(t => t.Cart);
            return View(trackOrders.ToList());
        }

        // GET: TrackOrders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TrackOrder trackOrder = db.TrackOrders.Find(id);
            if (trackOrder == null)
            {
                return HttpNotFound();
            }
            return View(trackOrder);
        }

        // GET: TrackOrders/Create
        public ActionResult Create()
        {
            ViewBag.CartId = new SelectList(db.Carts, "Id", "CustomerName");
            return View();
        }

        // POST: TrackOrders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CartId,Distance,DateOfPurchase,DateOfArrival")] TrackOrder trackOrder)
        {
            if (ModelState.IsValid)
            {
                db.TrackOrders.Add(trackOrder);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CartId = new SelectList(db.Carts, "Id", "CustomerName", trackOrder.CartId);
            return View(trackOrder);
        }

        // GET: TrackOrders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TrackOrder trackOrder = db.TrackOrders.Find(id);
            if (trackOrder == null)
            {
                return HttpNotFound();
            }
            ViewBag.CartId = new SelectList(db.Carts, "Id", "CustomerName", trackOrder.CartId);
            return View(trackOrder);
        }

        // POST: TrackOrders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,CartId,Distance,DateOfPurchase,DateOfArrival")] TrackOrder trackOrder)
        {
            if (ModelState.IsValid)
            {
                db.Entry(trackOrder).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CartId = new SelectList(db.Carts, "Id", "CustomerName", trackOrder.CartId);
            return View(trackOrder);
        }

        // GET: TrackOrders/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            TrackOrder trackOrder = db.TrackOrders.Find(id);
            if (trackOrder == null)
            {
                return HttpNotFound();
            }
            return View(trackOrder);
        }

        // POST: TrackOrders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            TrackOrder trackOrder = db.TrackOrders.Find(id);
            db.TrackOrders.Remove(trackOrder);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
