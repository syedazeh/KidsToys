﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KidsToysProject.Models;

namespace KidsToysProject.Controllers
{
    [Authorize(Users ="admin@admin.com")]
    public class ProductsController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        // GET: Products
        public ActionResult Index()
        {
           
            var products = db.Products.Include(p => p.Category);
            return View(products);
        }

        [AllowAnonymous]
        //GET: Products Grids
        public ActionResult ProductsGrid(string name, string Category, string sort, string price)
        {
            var products = from p in db.Products
                           select p;
            if (!String.IsNullOrEmpty(sort))
            {
                if (sort == "Descending")
                {
                    products = products.OrderByDescending(x => x.Price);
                }
                else if (sort == "Ascending")
                {
                    products = products.OrderBy(x => x.Price);
                }
                else
                {
                    products.ToList();
                }
            }
            if (!String.IsNullOrEmpty(price))
            {
                var priceInt = int.Parse(price);
                if (priceInt == 20)
                {
                    products = products.Where(p => p.Price >= priceInt && p.Price <= 35);
                }
                else if (priceInt == 35)
                {
                    products = products.Where(p => p.Price >= priceInt && p.Price <= 50);
                }
                else if (priceInt == 0)
                {
                    products.ToList();
                }
                else 
                {
                    products = products.Where(p => p.Price >= priceInt && p.Price <= 70);
                }
            }
            if (!String.IsNullOrEmpty(name))
            {
                products = products.Where(p => p.Name.Contains(name));
            }
            if (!String.IsNullOrEmpty(Category))
            {
                if (Category == "All")
                {
                    return View(products);
                }
                else
                {
                    products = products.Where(p => p.Category.Name == Category);
                }
            }
           
            if (products.Count() == 0)
            {
                TempData["massage"] = "No resutl found! Try a gain";
            }
            return View(products);
        }


        [AllowAnonymous]
        // GET: Products/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            var cusId = User.Identity.Name;
            Customer customer = db.Customers.Find(cusId);
            if (customer != null)
            {
                var recent = db.RecentlyVieweds.Where(x => x.ProductId == product.Id && x.CustomerName == cusId);
                if(recent.Count() == 0)
                {
                    RecentlyViewed recentlyViewed = new RecentlyViewed { ProductId = product.Id, CustomerName = cusId };
                    db.RecentlyVieweds.Add(recentlyViewed);
                    db.SaveChanges();
                }
               
            }
            return View(product);
        }

        [Authorize(Users = "admin@admin.com")]
        // GET: Products/Create
        public ActionResult Create()
        {
            ViewBag.CategortyId = new SelectList(db.Categories, "Id", "Name");
            return View();
        }

        // POST: Products/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,CategortyId,Name,Description,Image,Amount,Purchased,Price")] Product product)
        {
            var lst = db.Products.ToList();
            foreach (var x in lst)
            {
                if (x.Name == product.Name)
                {
                    TempData["duplicate"] = "duplicate records";
                    return RedirectToAction("Create");
                }
            }
            if (ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
               Notification notification = new Notification { ProductId = product.Id, CustomerName = User.Identity.Name, ProductName = product.Name, ProductPrice = product.Price, date = DateTime.Now };
                db.Notifications.Add(notification);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CategortyId = new SelectList(db.Categories, "Id", "Name", product.CategortyId);
            return View(product);
        }
        [Authorize(Users = "admin@admin.com")]
        // GET: Products/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            ViewBag.CategortyId = new SelectList(db.Categories, "Id", "Name", product.CategortyId);
            return View(product);
        }

        [Authorize(Users = "admin@admin.com")]
        // POST: Products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,CategortyId,Name,Description,Image,Amount,Purchased,Price")] Product product)
        {
          
            if (ModelState.IsValid)
            {
                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategortyId = new SelectList(db.Categories, "Id", "Name", product.CategortyId);
            return View(product);
        }

        [Authorize(Users = "admin@admin.com")]
        // GET: Products/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            if (product == null)
            {
                return HttpNotFound();
            }
            return View(product);
        }

        // POST: Products/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Product product = db.Products.Find(id);

            if (product.CartItems.Count() == 0)
            {
                db.Products.Remove(product);
                db.SaveChanges();
            }
            else
            {
                TempData["msg"] = "Item cannot be removed";
                return RedirectToAction("Delete");
            }

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
