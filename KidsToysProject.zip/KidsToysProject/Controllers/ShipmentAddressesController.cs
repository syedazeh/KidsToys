﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KidsToysProject.Models;

namespace KidsToysProject.Controllers
{
    [Authorize]
    public class ShipmentAddressesController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        // GET: ShipmentAddresses
        public ActionResult Index()
        {
            return View(db.ShipmentAddresses.ToList());
        }

        // GET: ShipmentAddresses/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShipmentAddress shipmentAddress = db.ShipmentAddresses.Find(id);
            if (shipmentAddress == null)
            {
                return HttpNotFound();
            }
            return View(shipmentAddress);
        }

        // GET: ShipmentAddresses/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ShipmentAddresses/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,BuildingNumber,StreetName,City")] ShipmentAddress shipmentAddress)
        {
            if (ModelState.IsValid)
            {
                db.ShipmentAddresses.Add(shipmentAddress);
                db.SaveChanges();
                //return RedirectToAction("Index");
                return RedirectToAction("ShipmentDetails", "Transaction", new { id = shipmentAddress.Id });
            }
            return View(shipmentAddress);
        }

        [Authorize(Users = "admin@admin.com")]
        // GET: ShipmentAddresses/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShipmentAddress shipmentAddress = db.ShipmentAddresses.Find(id);
            if (shipmentAddress == null)
            {
                return HttpNotFound();
            }
            return View(shipmentAddress);
        }

        [Authorize(Users = "admin@admin.com")]
        // POST: ShipmentAddresses/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,BuildingNumber,StreetName,City")] ShipmentAddress shipmentAddress)
        {
            if (ModelState.IsValid)
            {
                db.Entry(shipmentAddress).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(shipmentAddress);
        }

        [Authorize(Users = "admin@admin.com")]
        // GET: ShipmentAddresses/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ShipmentAddress shipmentAddress = db.ShipmentAddresses.Find(id);
            if (shipmentAddress == null)
            {
                return HttpNotFound();
            }
            return View(shipmentAddress);
        }

        [Authorize(Users = "admin@admin.com")]
        // POST: ShipmentAddresses/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ShipmentAddress shipmentAddress = db.ShipmentAddresses.Find(id);
            db.ShipmentAddresses.Remove(shipmentAddress);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
