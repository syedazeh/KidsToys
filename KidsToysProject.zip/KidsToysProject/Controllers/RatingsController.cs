﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KidsToysProject.Models;

namespace KidsToysProject.Controllers
{
   

    public class RatingsController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        [Authorize(Users = "admin@admin.com")]
        // GET: Ratings
        public ActionResult Index()
        {
            var ratings = db.Ratings.Include(r => r.Customer).Include(r => r.Product);
            return View(ratings.ToList());
        }

        // GET: Ratings/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rating rating = db.Ratings.Find(id);
            if (rating == null)
            {
                return HttpNotFound();
            }
            return View(rating);
        }

        // GET: Ratings/Create
        public ActionResult Create()
        {
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name");
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name");
            return View();
        }

        // POST: Ratings/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,ProductId,CustomerName,Comment,Date,Stars")] Rating rating)
        {
            if (ModelState.IsValid)
            {
                db.Ratings.Add(rating);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", rating.CustomerName);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", rating.ProductId);
            return View(rating);
        }

        [Authorize(Users = "admin@admin.com")]

        // GET: Ratings/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rating rating = db.Ratings.Find(id);
            if (rating == null)
            {
                return HttpNotFound();
            }
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", rating.CustomerName);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", rating.ProductId);
            return View(rating);
        }

        // POST: Ratings/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,ProductId,CustomerName,Comment,Date,Stars")] Rating rating)
        {
            if (ModelState.IsValid)
            {
                db.Entry(rating).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CustomerName = new SelectList(db.Customers, "UserName", "Name", rating.CustomerName);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", rating.ProductId);
            return View(rating);
        }

        [Authorize(Users = "admin@admin.com")]

        // GET: Ratings/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Rating rating = db.Ratings.Find(id);
            if (rating == null)
            {
                return HttpNotFound();
            }
            return View(rating);
        }

        // POST: Ratings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Rating rating = db.Ratings.Find(id);
            db.Ratings.Remove(rating);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        //////////////////////////////////////////////////////////////////////////////////////
        ///Ratings
        ///
        [Authorize]
        public ActionResult Ratings(int? id, string comment, string star)
        {

            int numStars = 0;
            var stringComment = "";

            if (!String.IsNullOrEmpty(star))
            {
                numStars = int.Parse(star);
            }
            else
            {
                return View();
            }
            if (!String.IsNullOrEmpty(comment))
            {
                stringComment = comment;
            }
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Product product = db.Products.Find(id);
            Rating ratings = new Rating { ProductId = product.Id, CustomerName = User.Identity.Name, Date = DateTime.Today, Comment = stringComment, Stars = numStars };
            var allRatings = db.Ratings.ToList();
            foreach (var r in allRatings)
            {
                if (r.ProductId == product.Id && r.CustomerName == User.Identity.Name)
                {
                    TempData["alreadyRated"] = "This product has already been rated by you!";
                    return RedirectToAction("Details", "Products", new { id = product.Id });
                }
            }
            TempData["numStars"] = numStars;
            TempData["stringComment"] = stringComment;
            db.Ratings.Add(ratings);
            db.SaveChanges();
            return RedirectToAction("Details", "Products", new { id = product.Id });

        }

    }
}
