﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using KidsToysProject.Models;

namespace KidsToysProject.Controllers
{
    [Authorize(Users = "admin@admin.com")]
    public class BookmarkItemsController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        // GET: BookmarkItems
        public ActionResult Index()
        {
            var bookmarkItems = db.BookmarkItems.Include(b => b.Bookmark).Include(b => b.Product);
            return View(bookmarkItems.ToList());
        }

        // GET: BookmarkItems/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BookmarkItem bookmarkItem = db.BookmarkItems.Find(id);
            if (bookmarkItem == null)
            {
                return HttpNotFound();
            }
            return View(bookmarkItem);
        }

        // GET: BookmarkItems/Create
        public ActionResult Create()
        {
            ViewBag.BookmarkId = new SelectList(db.Bookmarks, "Id", "CustomerName");
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name");
            return View();
        }

        // POST: BookmarkItems/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,ProductId,BookmarkId")] BookmarkItem bookmarkItem)
        {
            if (ModelState.IsValid)
            {
                db.BookmarkItems.Add(bookmarkItem);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.BookmarkId = new SelectList(db.Bookmarks, "Id", "CustomerName", bookmarkItem.BookmarkId);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", bookmarkItem.ProductId);
            return View(bookmarkItem);
        }

        // GET: BookmarkItems/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BookmarkItem bookmarkItem = db.BookmarkItems.Find(id);
            if (bookmarkItem == null)
            {
                return HttpNotFound();
            }
            ViewBag.BookmarkId = new SelectList(db.Bookmarks, "Id", "CustomerName", bookmarkItem.BookmarkId);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", bookmarkItem.ProductId);
            return View(bookmarkItem);
        }

        // POST: BookmarkItems/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,ProductId,BookmarkId")] BookmarkItem bookmarkItem)
        {
            if (ModelState.IsValid)
            {
                db.Entry(bookmarkItem).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BookmarkId = new SelectList(db.Bookmarks, "Id", "CustomerName", bookmarkItem.BookmarkId);
            ViewBag.ProductId = new SelectList(db.Products, "Id", "Name", bookmarkItem.ProductId);
            return View(bookmarkItem);
        }

        // GET: BookmarkItems/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BookmarkItem bookmarkItem = db.BookmarkItems.Find(id);
            if (bookmarkItem == null)
            {
                return HttpNotFound();
            }
            return View(bookmarkItem);
        }

        // POST: BookmarkItems/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BookmarkItem bookmarkItem = db.BookmarkItems.Find(id);
            db.BookmarkItems.Remove(bookmarkItem);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
