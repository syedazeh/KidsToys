﻿using KidsToysProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace KidsToysProject.Controllers
{

    public class HomeController : Controller
    {
        private KidsToysDBEntities db = new KidsToysDBEntities();

        public ActionResult Index()
        {
            var products = from p in db.Products
                           select p;
            products = products.OrderByDescending(x => x.Purchased);
            var recent = from r in db.RecentlyVieweds select r;
            recent = recent.Where(x => x.CustomerName == User.Identity.Name);
            if (recent.Count() != 0)
            {
                ViewBag.r = recent;
            }
            TempData["notification"] = "true";

            return View(products);
        }

     

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [Authorize(Users ="admin@admin.com")]
        public ActionResult Admin()
        {
            return View();
        }
    }
}